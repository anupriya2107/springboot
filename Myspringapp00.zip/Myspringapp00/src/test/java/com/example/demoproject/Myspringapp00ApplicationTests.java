package com.example.demoproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myspringapp00ApplicationTests {

	@Test
	void contextLoads() {
	}

}
